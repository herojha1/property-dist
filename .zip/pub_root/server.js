const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files from the "public" directory

// Dummy user data for demonstration
const validUser = {
    username: 'user',
    password: 'password123'
};

// Login route
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (username === validUser.username && password === validUser.password) {
        res.json({ success: true });
    } else {
        res.json({ success: false, message: 'Invalid username or password' });
    }
});

// Serve the home page
app.get('/home', (req, res) => {
    res.sendFile(__dirname + '/public/home.html');
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
